package edu.seg2105.client.backend;

import ocsf.client.*;

import java.io.*;

import edu.seg2105.client.common.*;

public class ChatClient extends AbstractClient {
    // Instance variables **********************************************
    ChatIF clientUI;
    String loginId; // Add loginId as an instance variable

    // Constructors ****************************************************
    public ChatClient(String loginId, String host, int port, ChatIF clientUI) throws IOException {
        super(host, port); // Call the superclass constructor
        this.clientUI = clientUI;
        this.loginId = loginId; // Store loginId
        openConnection();
    }

    // Instance methods ************************************************
    @Override
    protected void connectionEstablished() {
        try {
            sendToServer("#login " + loginId);
        } catch (IOException e) {
            clientUI.display("Error sending login ID to server: " + e.getMessage());
        }
    }

    @Override
    protected void connectionClosed() {
        clientUI.display("You have logged off! To terminate this client, please use #quit.");
    }

    @Override
    protected void connectionException(Exception exception) {
        clientUI.display("The Server has shut down.");
    }

    public void handleMessageFromServer(Object msg) {
        clientUI.display(msg.toString());
    }

    public void handleMessageFromClientUI(String message) {
        try {
            if (message.startsWith("#")) {
                handleCommand(message);
            } else if (isConnected()) {
                sendToServer(message);
            } else {
                clientUI.display("You are logged off. Please log in again before sending messages.");
            }
        } catch (IOException e) {
            clientUI.display("Could not send message to server. Terminating client.");
            quit();
        }
    }

    public void handleCommand(String msg) {
        if (msg.startsWith("#sethost")) {
            if (!isConnected()) {
                sethost(msg);
            } else {
                clientUI.display("Cannot change host while connected. Please log off first.");
            }
        } else if (msg.startsWith("#setport")) {
            if (!isConnected()) {
                setport(msg);
            } else {
                clientUI.display("Cannot change port while connected. Please log off first.");
            }
        } else {
            switch (msg) {
                case "#quit":
                    clientUI.display("___QUITTING___");
                    quit();
                    break;
                case "#logoff":
                    if (isConnected()) {
                        try {
                            closeConnection();
                        } catch (IOException e) {
                            clientUI.display("Error while logging off: " + e.getMessage());
                        }
                    } else {
                        clientUI.display("Not connected. Cannot LOGOFF.");
                    }
                    break;
                case "#login":
                    login();
                    break;
                case "#gethost":
                    clientUI.display("Current Host: " + getHost());
                    break;
                case "#getport":
                    clientUI.display("Current Port: " + getPort());
                    break;
                default:
                    clientUI.display("Invalid command: " + msg);
                    break;
            }
        }
    }

    private void sethost(String msg) {
        String[] host = msg.split(" ");
        if (host.length < 2) {
            clientUI.display("Error: No host specified. Usage: #sethost <hostname>");
            return;
        }
        setHost(host[1]);
        clientUI.display("Host set to: " + host[1]);
    }

    private void setport(String msg) {
        String[] port = msg.split(" ");
        if (port.length < 2) {
            clientUI.display("Error: No port specified. Usage: #setport <port>");
            return;
        }
        try {
            setPort(Integer.parseInt(port[1]));
            clientUI.display("Port set to: " + port[1]);
        } catch (NumberFormatException e) {
            clientUI.display("Invalid port number. Please enter a valid integer.");
        }
    }

    private void login() {
        if (!isConnected()) {
            try {
                openConnection();
            } catch (IOException e) {
                clientUI.display("Cannot Connect due to IO exception: " + e);
            }
        } else {
            clientUI.display("Client already connected.");
        }
    }

    public void quit() {
        try {
            closeConnection();
        } catch (IOException e) {
            clientUI.display("Error while quitting: " + e.getMessage());
        }
        System.exit(0);
    }
}
//End of ChatClient class
