// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package edu.seg2105.client.backend;

import ocsf.client.*;

import java.io.*;

import edu.seg2105.client.common.*;

/**
 * This class overrides some of the methods defined in the abstract
 * superclass in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 */
public class ChatClient extends AbstractClient {
	
    // Instance variables **********************************************
	  /**
	   * The interface type variable.  It allows the implementation of 
	   * the display method in the client.
	   */
	
    ChatIF clientUI;
    String loginId; // Add loginId as an instance variable

    // Constructors ****************************************************
    
    /**
     * Constructs an instance of the chat client.
     *
     * @param host The server to connect to.
     * @param port The port number to connect on.
     * @param clientUI The interface type variable.
     */
    public ChatClient(String loginId, String host, int port, ChatIF clientUI) throws IOException {
        super(host, port); // Call the superclass constructor
        this.clientUI = clientUI;
        this.loginId = loginId; // Store loginId
        openConnection();
    }

    // Instance methods ************************************************
    
    /**
     * This method handles all data that comes in from the server.
     *
     * @param msg The message from the server.
     */
    
    @Override
    protected void connectionEstablished() {
        try {
            sendToServer("#login " + loginId);
        } catch (IOException e) {
            clientUI.display("Error sending login ID to server: " + e.getMessage());
        }
    }

    /**
     * This hook method sets is called when the Connection is closed
     */
    @Override
    protected void connectionClosed() {
        clientUI.display("You have logged off! To terminate this client, please use #quit.");
    }
    
    /**
     * This hook method sets is called when the Connection is closed, but there is an exception
     */

    @Override
    protected void connectionException(Exception exception) {
        clientUI.display("The Server has shut down.");
    }
    
    /**
     * This method handles server messages
     */

    public void handleMessageFromServer(Object msg) {
        clientUI.display(msg.toString());
    }
    
    /**
     * This method handles all data coming from the UI            
     *
     * @param message The message from the UI.    
     */

    public void handleMessageFromClientUI(String message) {
        try {
            if (message.startsWith("#")) {
                handleCommand(message);
            } else if (isConnected()) {
                sendToServer(message);
            } else {
                clientUI.display("You are logged off. Please log in again before sending messages.");
            }
        } catch (IOException e) {
            clientUI.display("Could not send message to server. Terminating client.");
            quit();
        }
    }
    
    /**
     * This method handles all the commands the client might use
     * @param msg Initial message to find port
     */

    public void handleCommand(String msg) {
        if (msg.startsWith("#sethost")) {
            if (!isConnected()) {
                sethost(msg);
            } else {
                clientUI.display("Cannot change host while connected. Please log off first.");
            }
        } else if (msg.startsWith("#setport")) {
            if (!isConnected()) {
                setport(msg);
            } else {
                clientUI.display("Cannot change port while connected. Please log off first.");
            }
        } else {
            switch (msg) {
                case "#quit":
                    clientUI.display("___QUITTING___");
                    quit();
                    break;
                case "#logoff":
                    if (isConnected()) {
                        try {
                            closeConnection();
                        } catch (IOException e) {
                            clientUI.display("Error while logging off: " + e.getMessage());
                        }
                    } else {
                        clientUI.display("Not connected. Cannot LOGOFF.");
                    }
                    break;
                case "#login":
                    login();
                    break;
                case "#gethost":
                    clientUI.display("Current Host: " + getHost());
                    break;
                case "#getport":
                    clientUI.display("Current Port: " + getPort());
                    break;
                default:
                    clientUI.display("Invalid command: " + msg);
                    break;
            }
        }
    }

    
    /**
     * This method sets host
     * @param msg Initial message to find host
     */

    
    private void sethost(String msg) {
        String[] host = msg.split(" ");
        if (host.length < 2) {
            clientUI.display("Error: No host specified. Usage: #sethost <hostname>");
            return;
        }
        setHost(host[1]);
        clientUI.display("Host set to: " + host[1]);
        reconnect();
    }
    
    
    /**
     * This method sets port
     * @param msg Initial message to find port
     */




    private void setport(String msg) {
        String[] port = msg.split(" ");
        if (port.length < 2) {
            clientUI.display("Error: No port specified. Usage: #setport <port>");
            return;
        }
        try {
            setPort(Integer.parseInt(port[1]));
            clientUI.display("Port set to: " + port[1]);
            reconnect();
        } catch (NumberFormatException e) {
            clientUI.display("Invalid port number. Please enter a valid integer.");
        }
    }
    
    
    /**
     * This method sets the reconnection logic
     */

    

    private void reconnect() {
        try {
            closeConnection();
            openConnection(); // Reconnect with new host/port
        } catch (IOException e) {
            clientUI.display("Error reconnecting: " + e.getMessage());
        }
    }

    
    
    
    
    
    
    /**
     * This allows user to login
     */
    
    private void login() {
        if (!isConnected()) {
            try {
                openConnection();
            } catch (IOException e) {
                clientUI.display("Cannot Connect due to IO exception: " + e);
            }
        } else {
            clientUI.display("Client already connected.");
        }
    }
    
    
    /**
     * This method terminates the client.
     */

    public void quit() {
        try {
            closeConnection();
        } catch (IOException e) {
            clientUI.display("Error while quitting: " + e.getMessage());
        }
        System.exit(0);
    }
}
//End of ChatClient class
