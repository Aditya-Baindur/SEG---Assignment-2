package edu.seg2105.edu.server.backend;
// This file contains material supporting section 3.7 of the textbook:

import java.io.IOException;

// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract superclass in order
 * to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 */
public class EchoServer extends AbstractServer {
	// Class variables *************************************************

	/**
	 * The default port to listen on.
	 */
	final public static int DEFAULT_PORT = 5555;
	private boolean isStopped = false;
	private ServerConsole serverConsole; // serverConsole reference

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the echo server.
	 *
	 * @param port         The port number to connect on.
	 * @param SeverConsole Instance of Server Console, used for callback
	 */

	public EchoServer(int port, ServerConsole serverConsole) {
		super(port);
		this.serverConsole = serverConsole;
	}

	// Instance methods ************************************************

	/**
	 * Hook method called each time a new client connection is accepted.
	 * 
	 * @param client the connection connected to the client.
	 */

	@Override
	protected void clientConnected(ConnectionToClient client) {
		serverConsole.display("A new Client has connected");
	}

	/**
	 * Hook method called each time a client disconnects.
	 *
	 * @param client the connection with the client.
	 */
	@Override

	synchronized protected void clientDisconnected(ConnectionToClient client) {
		// Retrieve the loginId from the client's info
		String loginId = (String) client.getInfo("loginId");

		// If loginId is null (i.e., client didn't log in), show a generic message
		if (loginId != null) {
			serverConsole.display("Client " + loginId + " disconnected.");
		} else {
			serverConsole.display("Client with no login ID disconnected.");
		}
	}

	/**
	 * This method handles any messages received from the client.
	 *
	 * @param msg    The message received from the client.
	 * @param client The connection from which the message originated.
	 */

	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		serverConsole.display("Message received: " + msg + " from " + client.getInfo("loginId"));

		// Check if client is logged in
		if (client.getInfo("loginId") == null) {
			if (msg instanceof String && ((String) msg).startsWith("#login")) {
				// Handle login command
				String loginId = ((String) msg).substring(7).trim();
				if (!loginId.isEmpty()) {
					client.setInfo("loginId", loginId); // Set login ID
					try {
						client.sendToClient("Login successful, welcome " + loginId);
					} catch (IOException e) {
						serverConsole.display("Error sending login success message: " + e.getMessage());
					}
				} else {
					try {
						client.sendToClient("Error: Login ID cannot be empty");
						client.close(); // Close connection if login is invalid
					} catch (IOException e) {
						serverConsole.display("Error closing client connection: " + e.getMessage());
					}
				}
			} else {
				// Ask client to log in first
				try {
					client.sendToClient("Error: Please login first using the #login <loginid> command.");
					client.close(); // Close connection after sending the error message
				} catch (IOException e) {
					serverConsole.display("Error closing client connection: " + e.getMessage());
				}
			}
			return;
		}

		// After login, handle regular messages
		if (msg instanceof String) {
			String loginId = (String) client.getInfo("loginId");
			if (loginId != null) {
				String messageToSend = loginId + ": " + msg;
				try {
					client.sendToClient(messageToSend); // Send the message back to the sender
				} catch (IOException e) {
					serverConsole.display("Error sending message back to client: " + e.getMessage());
				}
			}
		}
	}

	/**
	 * This method processes different commands entered by the user on the server
	 * console.
	 *
	 * @param msg The command message entered by the user.
	 */

	public void handleCommand(String msg) {

		// If the command is #setport, ensure the server is fully closed
		if (msg.startsWith("#setport")) {
			String[] parts = msg.split(" ");
			if (!isListening() && getNumberOfClients() == 0) { // Only allow if server is fully closed
				if (parts.length > 1) { // Check if a port number is provided
					try {
						int newPort = Integer.parseInt(parts[1]);
						stopServer(); // Ensure we stop before changing port
						setPort(newPort); // Set the new port
						startServer(); // Start the server on the new port
						serverConsole.display("Current server port: " + getPort()); // Use get port to make sure port
																					// was correctly changed in the
																					// backend and OCSF
					} catch (NumberFormatException e) {
						serverConsole.display("Invalid port number.");
					}
				} else {
					serverConsole.display("No port number provided.");
				}
			} else {
				serverConsole.display(
						"Cannot set port: server must be fully closed. \nClose Server by running #close first. \nThen do #setport "
								+ parts[1]);
			}
			return; // End method after processing #setport
		}

		// Handle other commands
		switch (msg) {
		case "#quit":
			serverConsole.display("Server is quitting...");
			System.exit(0);
			break;
		case "#stop":
			stopServer();
			break;
		case "#close":
			closeServer();
			break;
		case "#start":
			startServer();
			break;
		case "#getport":
			serverConsole.display("Current server port: " + getPort());
			break;
		default:
			serverConsole.display("Invalid command: " + msg);
			break;
		}
	}

	// Stop server logic
	private void stopServer() {

		if (!isListening()) {
			serverConsole.display("Server is already stopped.");
		} else {
			stopListening();
			isStopped = true;
			serverConsole.display("Server has stopped listening for new connections.");
		}
	}

	// Close server logic
	private void closeServer() {
		stopServer();
		disconnectAllClients();
		serverConsole.display("Server has closed. All clients are disconnected.");
	}

	// Start server logic
	private void startServer() {
		if (isStopped) {
			try {
				listen();
				isStopped = false;
				serverConsole.display("Server started and listening on port " + getPort());
			} catch (IOException e) {
				serverConsole.display("Error: Could not bind to port " + getPort() + ". " + e.getMessage());
			}
		} else {
			serverConsole.display("Server is already running.");
		}
	}

	// Disconnect all clients
	private void disconnectAllClients() {
		Thread[] clientThreads = getClientConnections();
		for (Thread thread : clientThreads) {
			ConnectionToClient clientConnection = (ConnectionToClient) thread;
			try {
				clientConnection.close();
			} catch (IOException e) {
				serverConsole.display("Error disconnecting client: " + e.getMessage());
			}
		}
	}

	/**
	 * This method overrides the one in the superclass. Called when the server
	 * starts listening for connections.
	 */
	protected void serverStarted() {
		serverConsole.display("Server listening for connections on port " + getPort());
	}

	/**
	 * This method overrides the one in the superclass. Called when the server stops
	 * listening for connections.
	 */
	protected void serverStopped() {
		serverConsole.display("Server has stopped listening for connections.");
	}

}
//End of EchoServer class
