package edu.seg2105.edu.server.backend;

import java.util.Scanner;
import edu.seg2105.client.common.ChatIF;

/**
 * This class allows the server to read commands from the console and display messages.
 * It interfaces with the EchoServer to handle user input.
 */
public class ServerConsole implements ChatIF {
	
    private EchoServer server;

    // Constructor to link ServerConsole with EchoServer
    public ServerConsole(EchoServer server) {
        this.server = server;
    }

    /**
     * This method displays messages on the server console.
     *
     * @param message The message to display.
     */
    @Override
    public void display(String message) {
        System.out.println("SERVER MSG> " + message);
    }

    
    
    
    /**
     * This method listens for user input from the server's console and forwards it to the EchoServer.
     *
     * @param server The EchoServer instance to handle commands.
     */

    public void readConsoleInput() {
        @SuppressWarnings("resource") // TO NOT get the pesky warnings
        Scanner scanner = new Scanner(System.in);

        while (true) {
            String consoleMessage = scanner.nextLine();
            
            if (consoleMessage.startsWith("#")) {
   
                server.handleCommand(consoleMessage);
            } else {
                System.out.println("SERVER CONSOLE: " + consoleMessage);
                server.sendToAllClients("SERVER MSG > " + consoleMessage);
            }
        }
    }

    /**
     * The main method starts the EchoServer and listens for user input from the console.
     *
     * @param args Command-line arguments for the server.
     */
    public static void main(String[] args) {
        int port = EchoServer.DEFAULT_PORT;

        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.out.println("Invalid port number. Using default port: " + port);
            }
        }

        // Initialize and link console and server
        ServerConsole console = new ServerConsole(null);
        EchoServer server = new EchoServer(port, console);
        console.server = server; // Set server reference in console

        try {
            server.listen(); // Start listening for client connections
            console.readConsoleInput(); // Start reading commands
        } catch (Exception e) {
            System.out.println("ERROR - Could not start server.");
        }
    }
    
    
}
